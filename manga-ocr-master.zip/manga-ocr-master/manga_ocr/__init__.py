from ._version import __version__ as __version__
from manga_ocr.ocr import MangaOcr as MangaOcr

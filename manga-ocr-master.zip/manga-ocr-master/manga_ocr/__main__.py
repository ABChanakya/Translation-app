import fire

from manga_ocr.run import run


def main():
    fire.Fire(run)


if __name__ == "__main__":
    main()
